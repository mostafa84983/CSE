#include "../lib/HAL/LCD/LCD_interface.h"
#include "../lib/HAL/KEYPAD/KEYPAD_interface.h"


DIO_VidSetPinValue(Port_C, Pin3, PinHigh);

// int main(){
//     KEYPAD_VidInitDirectMode();
//     LCD_VidInit("Testing DEL!");
//     LCD_VidPrintString("Delete ME");

//     u8 Local_u8Button = NOT_PRESSED;

//     while(1){
//         WaitForKey(&Local_u8Button);
//         LCD_VidDeleteChar();
//     }
//     DIO_VidSetPinValue(Port_C)
// }