#ifndef SEV_SEG_COUNTER_H_
#define SEV_SEG_COUNTER_H_

#include "../../include/std_types.h"

void sev_seg_counter(u8 Local_u8Counter);

#endif