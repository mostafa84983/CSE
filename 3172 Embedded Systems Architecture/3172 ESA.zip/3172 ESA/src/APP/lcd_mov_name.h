#ifndef LCD_MOV_NAME_H_
#define LCD_MOV_NAME_H_

void lcd_mov_name(char str[]);

#endif